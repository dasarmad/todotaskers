
initApp = function() {
    firebase.auth().onAuthStateChanged(function(user) {
      if (user) {
        uid = user.uid
        var email = user.email;
        var name = email.substring(0, email.lastIndexOf("@"));

        console.log(user);
        document.getElementById("username").innerHTML = `<a class="nav-link btn" href="index.html"><i class="far fa-user-circle"></i> ${name}</a>`
        fetchTasks();
      } else {
        window.location.replace("login.html");
      }
    }, function(error) {
      console.log(error);
    });
  };

  window.addEventListener('load', function() {
    initApp()
  });

function doLogout() {
    firebase.auth().signOut().then(() => {
        window.location.replace("login.html");
        // Sign-out successful.
    }).catch((error) => {
        alert(error.message)
        // An error happened.
    });
}

new ClipboardJS('.btn');

const task_submit = document.getElementById("task_submit");
const error_message = document.getElementById("error_message");
const success_message = document.getElementById("success_message");

$('#task_form').submit(function(evt) {
  task_submit.innerHTML = `<button id="submit-button" type="button" class="btn btn-success btn-sm w-50 h-100" >Please wait <i class="fa fa-spinner fa-spin"></i></button>`
  error_message.innerHTML = '';
  success_message.innerHTML = '';

    // Target the form elements by their ids
    // And build the form object like this using jQuery:
    var formData = {
      "task_title": $('#task_title').val(),
      "task_description": $('#task_description').val()
      //$("input[name=nameGoesHere]").val();
    }

    evt.preventDefault(); //Prevent the default form submit action

    console.log(formData);
    pushTask(formData.task_title, formData.task_description)
})

function pushTask(title, description) {

  const current_date = Date.now();
  
  var newRef = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks');
  newRef.child(current_date).set({
    title: title,
    description: description,
    user_id: firebase.auth().currentUser.uid,
    task_timestamp: current_date
  }).then(() => {
    task_submit.innerHTML =   `<button type="submit" class="w-25 btn btn-sm btn-success">Submit</button>`
    success_message.innerHTML = 'You task has been submitted!';
    console.log("Document successfully written!");
  }).catch((error) => {
    error_message.innerHTML = error.error_message;
    console.error("Error writing document: ", error);
  });
}


const populate_tasks = document.getElementById('populate_tasks');

function fetchTasks() {
  var ref = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks');
    console.log(ref);
    ref.orderByKey().on("value", function(snapshot) {
      var content = ''
      populate_tasks.innerHTML = '';
        if (snapshot.exists()) {
            
            console.log(`Snapshot:`);
            console.log(snapshot.key);
            console.log(snapshot.val());
        
            
            snapshot.forEach(function(childSnapshot) {
              if ( childSnapshot.exists()){
                console.log(childSnapshot.val());
                // Your modified getHTML function
                //const getHTML = message => _.unescape(message).replace('\\', '');
                var title = childSnapshot.child('title').val().replace(/(<br>|<\/br>|<br \/>)/mgi, "\n");
                var description = childSnapshot.child('description').val().replace(/(<br>|<\/br>|<br \/>)/mgi, "\n");


                content += `<div class="col-md-6 col-lg-4 animated fadeIn">
                <div class="card mb-4 shadow-sm">
                  <div class="card-body ">`

                    if(!childSnapshot.child('task_status').val()){
                      content+=`<p class="card-text rounded bg-warning text-dark p-1 d-inline-flex shadow-sm mr-1"><small class="tag font-weight-bold"><i class="fas fa-exclamation-circle"></i> Pending</small></p>`
                    } else {
                      content+=`<p class="card-text rounded bg-success text-white p-1 d-inline-flex shadow-sm mr-1"><small class="tag font-weight-bold"><i class="fas fa-check-circle"></i> Completed</small></p>`
                    }

                    content+=`<p class="card-text rounded bg-primary text-white p-1 d-inline-flex shadow-sm mr-1"><small class="tag font-weight-bold">Created at: ${timeConverter(childSnapshot.child('task_timestamp').val())}</small></p>
                    
                    <p class="card-title">${childSnapshot.child('title').val()}</p>
                    <p id="description" class="card-text text-justify">${childSnapshot.child('description').val()}</p>`

                    if (!childSnapshot.child('task_status').val()) {
                      content+=`<p> <small class="text-muted">by <span class="card-creator">${firebase.auth().currentUser.displayName}</span></small> </p>
                      <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group w-100">
                          <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#exampleModalCenter" onclick="viewTask('${childSnapshot.key}')">View</button>
                          <button type="button" class="btn btn-sm btn-outline-secondary" onclick="markCompleted('${childSnapshot.key}')">Mark Completed</button>
                          <button id="button_copy_link_${childSnapshot.key}" type="button" class="btn btn-sm btn-outline-secondary" data-clipboard-text="https://todotaskers.web.app/shared-task.html?task=${childSnapshot.key}" onclick="shareTask('${childSnapshot.key}','${childSnapshot.val()}')">Copy Link</button>
                        </div>`
                    } else {  
                      content+=`
                        <p> <small class="text-muted">by <span class="card-creator">${firebase.auth().currentUser.displayName}</span></small> </p>
                        <div class="d-flex justify-content-between align-items-center">
                          <div class="btn-group w-100">
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#exampleModalCenter" onclick="viewTask('${childSnapshot.key}')">View</button>
                          </div>`
                    } 
                     
                      
                      content+=`</div>
                    </div>
                  </div>
                </div>`
                populate_tasks.innerHTML = content
                $(".animated").addClass("delay-1s");
              }
            });
          } else {
            populate_tasks.innerHTML = `<div class="col-md-12"><p class="lead text-dark">No task exist!</p></div>`
          }
        });           
}

function timeConverter(UNIX_timestamp){
  var a = new Date(UNIX_timestamp);
      var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      var year = a.getFullYear();
      var month = months[a.getMonth()];
      var date = a.getDate();
      var nowHour = a.getHours();
      var nowMinutes = a.getMinutes();
      var sec = a.getSeconds();

    var suffix = nowHour >= 12 ? "PM" : "AM";
    nowHour = (suffix == "PM" & (nowHour > 12 & nowHour < 24)) ? (nowHour - 12) : nowHour;
    nowHour = nowHour == 0 ? 12 : nowHour;
    nowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
    var currentTime = date + ' ' + month + ' ' + year + ' - ' + nowHour + ":" + nowMinutes + ' ' + suffix;
            
  return currentTime
}

function viewTask(key) {

  var ref = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks');
    console.log(ref);
    ref.child(key).orderByKey().on("value", function(snapshot) {
      var title = snapshot.child('title').val()
      var description = snapshot.child('description').val()

      console.log(title);
      console.log(description);

      document.getElementById('exampleModalLongTitle').innerHTML = title;
      document.getElementById('exampleModalLongBody').innerHTML = description;
    })

  
}

function markCompleted(key) {
  var newRef = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks');
  newRef.child(key).update({
    task_status: "Completed",
    task_shared: false
  }).then(() => {
    console.log("Task successfully updated!");
  }).catch((error) => {
    console.error("Error updating Task: ", error);
    alert(error.message);
  });
}

function shareTask(key, snapshot) {
  const button_copy_link_ = document.getElementById(`button_copy_link_${key}`)
  button_copy_link_.innerHTML = "Copying..."
  var newRef = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks');
  //var pushRef = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks').push();
  //var pushKey = pushRef.key;
  newRef.child(key).update({
    task_shared: true,
    //shared_key: pushKey 
  }).then(() => {
    console.log("Task successfully updated!");
    const button_copy_link_ = document.getElementById(`button_copy_link_${string}`)
    button_copy_link_.innerHTML = "Link Copied!"
    setTimeout(function(){ button_copy_link_.innerHTML = "Copy Link" }, 2000);
  }).catch((error) => {
    console.error("Error updating Task: ", error);
    alert(error.message);
  });
}


/**
 * Copy a string to clipboard
 * @param  {String} string         The string to be copied to clipboard
 * @return {Boolean}               returns a boolean correspondent to the success of the copy operation.
 */
 function copyLink(string) {
  var copyText = `https://todotaskers.web.app/shared-task.html?task=${string}`
  
  let textarea;
  let result;

  try {
    textarea = document.createElement('textarea');
    textarea.setAttribute('readonly', true);
    textarea.setAttribute('contenteditable', true);
    textarea.style.position = 'fixed'; // prevent scroll from jumping to the bottom when focus is set.
    textarea.value = copyText;

    document.body.appendChild(textarea);

    textarea.focus();
    textarea.select();

    const range = document.createRange();
    range.selectNodeContents(textarea);

    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);

    textarea.setSelectionRange(0, textarea.value.length);
    result = document.execCommand('copy');
  } catch (err) {
    console.error(err);
    result = null;
  } finally {
    document.body.removeChild(textarea);
  }

  // manual copy fallback using prompt
  if (!result) {
    const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    const copyHotkey = isMac ? '⌘C' : 'CTRL+C';
    result = prompt(`Press ${copyHotkey}`, copyText); // eslint-disable-line no-alert
    if (!result) {
      return false;
    }
  }
  
  return true;
}


const extra_div = document.getElementById("extra");
const important_message = document.getElementById("important-message");

function copyToClipboard(params, el) {
  var copyText = `https://todotaskers.web.app/shared-task.html?task=${params}`
  
  important_message.value = copyText
  // resolve the element
  el = (typeof el === 'string') ? document.querySelector(el) : el;

  // handle iOS as a special case
  if (navigator.userAgent.match(/ipad|ipod|iphone/i)) {

      // save current contentEditable/readOnly status
      var editable = el.contentEditable;
      var readOnly = el.readOnly;

      // convert to editable with readonly to stop iOS keyboard opening
      el.contentEditable = true;
      el.readOnly = true;

      // create a selectable range
      var range = document.createRange();
      range.selectNodeContents(el);

      // select the range
      var selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      el.setSelectionRange(0, 999999);

      // restore contentEditable/readOnly to original state
      el.contentEditable = editable;
      el.readOnly = readOnly;
  }
  else {
      el.select();
  }

  // execute copy command
  document.execCommand('copy');
}
