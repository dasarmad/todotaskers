window.addEventListener('load', function() {
  fetchTasks()
});

function doLogout() {
    firebase.auth().signOut().then(() => {
        window.location.replace("login.html");
        // Sign-out successful.
    }).catch((error) => {
        alert(error.message)
        // An error happened.
    });
}

const task_submit = document.getElementById("task_submit");
const error_message = document.getElementById("error_message");
const success_message = document.getElementById("success_message");

$('#task_form').submit(function(evt) {
  task_submit.innerHTML = `<button id="submit-button" type="button" class="btn btn-success btn-sm w-50 h-100" >Please wait <i class="fa fa-spinner fa-spin"></i></button>`
  error_message.innerHTML = '';
  success_message.innerHTML = '';

    // Target the form elements by their ids
    // And build the form object like this using jQuery:
    var formData = {
      "task_title": $('#task_title').val(),
      "task_description": $('#task_description').val()
      //$("input[name=nameGoesHere]").val();
    }

    evt.preventDefault(); //Prevent the default form submit action

    console.log(formData);
    pushTask(formData.task_title, formData.task_description)
})

function pushTask(title, description) {

  const current_date = Date.now();
  
  var newRef = firebase.database().ref('users').child(firebase.auth().currentUser.uid).child('tasks');
  newRef.child(current_date).set({
    title: title,
    description: description,
    user_id: firebase.auth().currentUser.uid,
    task_timestamp: current_date
  }).then(() => {
    task_submit.innerHTML =   `<button type="submit" class="w-25 btn btn-sm btn-success">Submit</button>`
    success_message.innerHTML = 'You task has been submitted!';
    console.log("Document successfully written!");
  }).catch((error) => {
    error_message.innerHTML = error.error_message;
    console.error("Error writing document: ", error);
  });
}


const populate_tasks = document.getElementById('populate_tasks');

fetchTasks = function () {
  var url_string = window.location.href
  var url = new URL(url_string);
  var task = url.searchParams.get("task");
  var ref = firebase.database().ref('shared-tasks').child(task);
    console.log(ref);
    ref.orderByKey().on("value", function(snapshot) {
      var content = ''
      populate_tasks.innerHTML = '';
        if (snapshot.exists()) {
            
            console.log(`Snapshot:`);
            console.log(snapshot.key);
            console.log(snapshot.val());
                


                content += `<div class="col-md-12 col-lg-6 animated fadeIn">
                <div class="card mb-4 shadow-sm">
                  <div class="card-body ">`

                    if(!snapshot.child('task_status').val()){
                      content+=`<p class="card-text rounded bg-warning text-dark p-1 d-inline-flex shadow-sm mr-1"><small class="tag font-weight-bold"><i class="fas fa-exclamation-circle"></i> Pending</small></p>`
                    } else {
                      content+=`<p class="card-text rounded bg-success text-white p-1 d-inline-flex shadow-sm mr-1"><small class="tag font-weight-bold"><i class="fas fa-check-circle"></i> Completed</small></p>`
                    }

                    content+=`<p class="card-text rounded bg-primary text-white p-1 d-inline-flex shadow-sm mr-1"><small class="tag font-weight-bold">Created at: ${timeConverter(snapshot.child('task_timestamp').val())}</small></p>
                    
                    <p class="card-title">${snapshot.child('title').val()}</p>
                    <p id="description" class="card-text text-justify">${snapshot.child('description').val()}</p>`

                    if (!snapshot.child('task_status').val()) {
                      content+=`<p> <small class="text-muted">by <span class="card-creator">${snapshot.child('created_by').val().substring(0, snapshot.child('created_by').val().lastIndexOf("@"))}</span></small> </p>
                      <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group w-100">
                          <button type="button" class="btn btn-sm btn-outline-secondary w-100" data-toggle="modal" data-target="#exampleModalCenter" onclick="viewTask('${snapshot.key}')">View</button>
                          <button id="button_mark_link_${snapshot.key}" type="button" class="btn btn-sm btn-outline-secondary w-100" onclick="markCompleted('${snapshot.key}')">Mark Completed</button>
                          <!--<button id="button_copy_link_${snapshot.key}" type="button" class="btn btn-sm btn-outline-secondary" onclick="shareTask('${snapshot.key}')">Copy Link</button>-->
                        </div>`
                    } else {  
                      content+=`
                        <p> <small class="text-muted">by <span class="card-creator">${snapshot.child('created_by').val().substring(0, snapshot.child('created_by').val().lastIndexOf("@"))}</span></small> </p>
                        <div class="d-flex justify-content-between align-items-center">
                          <div class="btn-group w-100">
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#exampleModalCenter" onclick="viewTask('${snapshot.key}')">View</button>
                          </div>`
                    } 
                     
                      
                      content+=`</div>
                    </div>
                  </div>
                </div>`
                populate_tasks.innerHTML = content
            
          } else {
            populate_tasks.innerHTML = `<div class="col-md-12"><p class="lead text-dark">This task marked as completed. Thank You!</p></div>`
          }
        });           
}

function timeConverter(UNIX_timestamp){
  var a = new Date(UNIX_timestamp);
      var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      var year = a.getFullYear();
      var month = months[a.getMonth()];
      var date = a.getDate();
      var nowHour = a.getHours();
      var nowMinutes = a.getMinutes();
      var sec = a.getSeconds();

    var suffix = nowHour >= 12 ? "PM" : "AM";
    nowHour = (suffix == "PM" & (nowHour > 12 & nowHour < 24)) ? (nowHour - 12) : nowHour;
    nowHour = nowHour == 0 ? 12 : nowHour;
    nowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
    var currentTime = date + ' ' + month + ' ' + year + ' - ' + nowHour + ":" + nowMinutes + ' ' + suffix;
            
  return currentTime
}

function viewTask(key) {

  var ref = firebase.database().ref('shared-tasks');
    console.log(ref);
    ref.child(key).orderByKey().once("value", function(snapshot) {
      var title = snapshot.child('title').val()
      var description = snapshot.child('description').val()

      console.log(title);
      console.log(description);

      document.getElementById('exampleModalLongTitle').innerHTML = title;
      document.getElementById('exampleModalLongBody').innerHTML = description;
    })

  
}

function markCompleted(key) {

  document.getElementById(`button_mark_link_${key}`).innerHTML = '...'

    var sar = {uid: key}

    var objectDataString = JSON.stringify(sar);
    
    console.log(objectDataString);
    $.ajax({
      //crossDomain: true,
      url:"https://us-central1-todotaskers.cloudfunctions.net/markCompletePublicTask",
      type:"post",
      dataType: "json",
      contentType:"application/json",
      data: objectDataString,
      success: function (result) {
        console.log(result.res); 
      },
      error: function (result) {
        console.log("Got an error" + JSON.stringify(result.res));
        alert('Error: Something went wrong! Please try again.');
      }
    });
}